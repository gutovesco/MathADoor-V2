#include <math.h>
static double funcao1(double k){

    return (k);
}
