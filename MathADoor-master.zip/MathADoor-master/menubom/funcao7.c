#include <math.h>
static double funcao7(double x)
{
    return (1/x);
}
