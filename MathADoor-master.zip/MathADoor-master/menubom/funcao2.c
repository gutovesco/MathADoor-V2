#include <math.h>
static double funcao2(double x, double k)
{
    return (pow(x,k));
}
