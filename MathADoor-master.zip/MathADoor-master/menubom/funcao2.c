#include <math.h>
static double funcao2(double x, double n)
{
    return (pow(x,n));
}
