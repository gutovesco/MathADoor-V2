#include <math.h>
static double funcao5(double x)
{
    return (log10(x));
}
