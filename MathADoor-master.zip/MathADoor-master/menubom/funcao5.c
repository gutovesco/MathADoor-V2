#include <math.h>
static double funcao5(double x, double k)
{
    return (log(x)/log(k));
}
