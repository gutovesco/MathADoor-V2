#include <math.h>
static double funcao4(double euler, double x){

    return(pow(euler, x));
}
