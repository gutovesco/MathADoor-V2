#include <math.h>
static double funcao10(double x)
{
    return (tan(x));
}
