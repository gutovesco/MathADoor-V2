#include <math.h>
static double funcao3(double k, double x)
{
    return (pow(k,x));
}
