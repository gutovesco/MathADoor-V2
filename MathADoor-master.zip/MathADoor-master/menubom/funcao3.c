#include <math.h>
static double funcao3(double b, double x)
{
    return (pow(b,x));
}
