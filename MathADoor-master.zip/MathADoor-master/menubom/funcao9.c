#include <math.h>
static double funcao9(double x)
{
    return (cos(x));
}
