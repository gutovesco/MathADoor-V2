#include <math.h>
static double funcao8(double x)
{
    return (sin(x));
}
