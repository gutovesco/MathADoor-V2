#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "funcao1.c"
#include "funcao2.c"
#include "funcao3.c"
#include "funcao4.c"
#include "funcao5.c"
#include "funcao6.c"
#include "funcao7.c"
#include "funcao8.c"
#include "funcao9.c"
#include "funcao10.c"

void Limpeza()
{
    system("cls || clear");
}
double der1(double k, double h){
    double w, derivada;
    w = k + h;
    derivada = ((funcao1(w) - funcao1(k)) / h);
    return (derivada);
}

double der2(double x, double k, double h){
    double w, derivada;
    w = x + h;
    derivada = ((funcao2(w,k) - funcao2(x,k)) / h);
    return (derivada);
}

double der3(double k, double x, double h){
    double w, derivada;
    w = x + h;
    derivada = ((funcao3(k,w) - funcao3(k,x)) / h);
    return (derivada);
}

double der4(double x, double h, double euler){
    double w, derivada;
    w = x + h;
    derivada = ((funcao4(euler,w) - funcao4(euler,x)) / h);
    return (derivada);
}

double der5(double x, double k, double h){
    double w, derivada;
    w = x + h;
    derivada = ((funcao5(w,k) - funcao5(x,k)) / h);
    return (derivada);
}

double der6(double x, double h){
    double w, derivada;
    w = x + h;
    derivada = ((funcao6(w) - funcao6(x)) / h);
    return (derivada);
}
double der7(double x, double h){
    double w, derivada;
    w = x + h;
    derivada = ((funcao7(w) - funcao7(x)) / h);
    return (derivada);
}

double der8(double x, double h){
    double w, derivada;
    w = x + h;
    derivada = ((funcao8(w) - funcao8(x)) / h);
    return (derivada);
}

double der9(double x, double h){
    double w, derivada;
    w = x + h;
    derivada = ((funcao9(w) - funcao9(x)) / h);
    return (derivada);
}

double der10(double x, double h){
    double w, derivada;
    w = x + h;
    derivada = ((funcao10(w) - funcao10(x)) / h);
    return (derivada);
}

int main()
{
    int m1, m2, m3, m4, i;
    double derivada, N, B, w, h, k, sum, logaritmo_xbasek, n, x, resultado, a, b, c;
    double euler = 2.718281828;
    printf("*Bem vindo ao MathADoor*\n");
    do{
        printf("--------------------------------------------------------\nEscolha no menu em seguida a conta que deseja realizar\n");
        printf("\n1 - Funcoes\n2 - Derivadas\n3 - Integrais\n4 - Sair\n");
        printf("\nIr para: ");
        scanf("%d", &m1);
        Limpeza();
        switch (m1)
        {
            case 1 :
                printf("Voce escolheu a opcao de Funcoes\n---------------------------------------\n");
                printf("Escolha agora qual funcao voce quer realizar:\n");
                printf("1 - F(x) = k\n");
                printf("2 - F(x) = x^k\n");
                printf("3 - F(x) = k^x\n");
                printf("4 - F(x) = e^x\n");
                printf("5 - F(x) = log(x)\n");
                printf("6 - F(x) = ln(x)\n");
                printf("7 - F(x) = 1/x\n");
                printf("8 - F(x) = Sen(x)\n");
                printf("9 - F(x) = Cos(x)\n");
                printf("10 - F(x) = Tg(x)\nIr para: ");
                scanf("%d", &m2);
                switch (m2)
                {
                    case 1 :
                        Limpeza();
                        printf("\nQue valor de k deseja aplicar? ");
                        scanf("%lf", &k);
                        resultado = funcao1(k);
                        printf("f(%lf) = %lf\n", k, resultado);
                        break;
                    case 2 :
                        Limpeza();
                        printf("Digite o valor de k para a construcao da funcao: ");
                        scanf("%lf", &k);
                        printf("\nQue valor de x deseja aplicar? \n");
                        scanf("%lf", &x);
                        resultado = funcao2(x, k);
                        printf("f(%lf) = %lf\n", x, resultado);
                        break;
                    case 3 :
                        Limpeza();
                        printf("\nDigite o valor de k para a construcao da funcao: ");
                        scanf("%lf", &k);
                        printf("Que valor de x deseja aplicar? ");
                        scanf("%lf", &x);
                        resultado = funcao3(k, x);
                        printf("Resultado da funcao: %lf\n", resultado);
                        break;
                    case 4 :
                        Limpeza();
                        printf("Que valor de x deseja aplicar? ");
                        scanf("%lf", &x);
                        resultado = funcao4(euler, x);
                        printf("f(%lf) = %lf\n", x, resultado);
                        break;
                    case 5 :
                        Limpeza();
                        do{
                            printf("Que valor de x deseja aplicar? ");
                            scanf("%lf", &x);
                            printf("\nDigite o valor de k: ");
                            scanf("%lf", &k);
                            printf("\n**************\nValor invalido para X");
                        }while(x <= 0);
                        logaritmo_xbasek = funcao5(x,k);
                        printf("f(%lf) = %lf\n", x, logaritmo_xbasek);
                        break;
                    case 6 :
                        Limpeza();
                        do{
                            printf("Que valor de x deseja aplicar? ");
                            scanf("%lf", &x);
                            printf("\n****************\nValor invalido para X");
                        }while(x <= 0);
                        resultado = funcao6(x);
                        printf("f(%lf) = %lf\n", x, resultado);
                        break;
                    case 7 :
                        Limpeza();
                        do{
                            printf("Que valor de x deseja aplicar? ");
                            scanf("%lf", &x);
                            printf("\n**************\nValor invalido para X");
                        }while(x == 0);
                        resultado = 1 / funcao7(x);
                        printf("f(%lf) = %lf\n", x, resultado);
                        break;
                    case 8 :
                        Limpeza();
                        printf("Que valor de x deseja aplicar? ");
                        scanf("%lf", &x);
                        resultado = funcao8(x);
                        printf("f(%lf) = %lf\n", x, resultado);
                        break;
                    case 9 :
                        Limpeza();
                        printf("Que valor de x deseja aplicar? ");
                        scanf("%lf", &x);
                        resultado = funcao9(x);
                        printf("f(%lf) = %lf\n", x, resultado);
                        break;
                    case 10 :
                        Limpeza();
                        printf("Que valor de x deseja aplicar? ");
                        scanf("%lf", &x);
                        resultado = funcao10(x);
                        printf("f(%lf) = %lf\n", x, resultado);
                        break;
                    default:
                        printf("\n");
                        printf("Voce nao escolheu nenhuma das opcoes!\n");
                }
                    break;

            case 2 :
                printf("Voce escolheu a opcao de Derivadas\n");
                printf("Escolha agora qual funcao voce quer realizar:\n");
                printf("1 - F(x) = k\n");
                printf("2 - F(x) = x^k\n");
                printf("3 - F(x) = k^x\n");
                printf("4 - F(x) = e^x\n");
                printf("5 - F(x) = log(x)\n");
                printf("6 - F(x) = ln(x)\n");
                printf("7 - F(x) = 1/x\n");
                printf("8 - F(x) = Sen(x)\n");
                printf("9 - F(x) = Cos(x)\n");
                printf("10 - F(x) = tg(x)\nIr para: ");
                scanf("%d", &m3);
                switch (m3)
                {
                    case 1 :
                        Limpeza();
                        printf("Digite o valor de k: ");
                        scanf("%lf", &k);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der1(k,h);
                        printf("Derivada de k: %lf\n", resultado);
                        break;
                    case 2 :
                        Limpeza();
                        printf("\nDigite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de n: ");
                        scanf("%lf", &n);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der2(x,n,h);
                        printf("Derivada de x^n: %lf\n", resultado);
                        break;
                    case 3:
                        Limpeza();
                        printf("\nDigite o valor de b: ");
                        scanf("%lf", &b);
                        printf("Digite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der3(b,x,h);
                        printf("Derivada de b^x: %lf\n", resultado);
                        break;
                    case 4:
                        Limpeza();
                        printf("\nDigite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der4(x,h,euler);
                        printf("Derivada de e^x: e^x\n");
                        printf("Derivada de e^%lf: %lf\n",x, resultado);
                        break;
                    case 5:
                        Limpeza();
                        printf("\nDigite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der5(x,k,h);
                        printf("Derivada de log10: %lf\n", resultado);
                        break;
                    case 6:
                        Limpeza();
                        printf("\nDigite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der6(x,h);
                        printf("Derivada de ln(x): %lf\n", resultado);
                        break;
                    case 7:
                        Limpeza();
                        printf("\nDigite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der7(x,h);
                        printf("Derivada de 1/x: %lf\n", resultado);
                        break;
                    case 8:
                        Limpeza();
                        printf("\nDigite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der8(x,h);
                        printf("Derivada de seno(x): %lf\n", resultado);
                        break;
                    case 9:
                        Limpeza();
                        printf("\nDigite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der9(x,h);
                        printf("Derivada de cosseno(x): %lf\n", resultado);
                        break;
                    case 10:
                        Limpeza();
                        printf("\nDigite o valor de x: ");
                        scanf("%lf", &x);
                        printf("Digite o valor de h: ");
                        scanf("%lf", &h);
                        resultado = der10(x,h);
                        printf("Derivada de tg(x): %lf\n", resultado);

                }
                    break;

                case 3 :
                printf("Voce escolheu a opcao de Integral\n");
                printf("Escolha agora qual funcao voce quer realizar:\n");
                printf("1 - F(x) = k\n");
                printf("2 - F(x) = x^n\n");
                printf("3 - F(x) = b^x\n");
                printf("4 - F(x) = e^x\n");
                printf("5 - F(x) = log(x)\n");
                printf("6 - F(x) = ln(x)\n");
                printf("7 - F(x) = 1/x\n");
                printf("8 - F(x) = Sen(x)\n");
                printf("9 - F(x) = Cos(x)\n");
                printf("10 - F(x) = tg(x)\nIr para: ");
                scanf("%d", &m4);
                switch (m4)
                {
                    case 1 :
                        Limpeza();
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        h = (b-a)/N;
                        for (i=1;i<=N-1;i++){
                        k = a + (i*h);
                        sum = sum + funcao1(k);
                        }
                        resultado = (((funcao1(a) + (2*sum) + funcao1(b))) * h) / 2;
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 2 :
                        Limpeza();
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Valor de k: ");
                        scanf("%lf", &k);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        h = (b-a)/N;
                        printf("valor de h: %lf\n\n", h);
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao2(x,k);
                        }
                        printf("%lf", sum);
                        resultado = (((funcao2(a,k) + (2*sum) + funcao2(b,k))) * h) / 2;
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 3 :
                        Limpeza();
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &B);
                        printf("Valor de k: ");
                        scanf("%lf", &k);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        h = (B-a)/N;
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao3(k,x);
                        }
                        resultado = (((funcao3(a,x) + (2*sum) + funcao3(B,x))) * h) / 2;
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 4 :
                        Limpeza();
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        h = (b-a)/N;
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao4(euler,x);
                        }
                        resultado = (((funcao4(a,x) + (2*sum) + funcao4(b,x))) * h) / 2;
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 5 :
                        Limpeza();
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Valor de k: ");
                        scanf("%lf", &k);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        h = (b-a)/N;
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao5(x,k);
                        }
                        resultado = (((funcao5(a,k) + (2*sum) + funcao5(b,k))) * h) / 2;
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 6 :
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Valor de x: ");
                        scanf("%lf", &x);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        h = (b-a)/N;
                        printf("valor de h: %lf\n\n", h);
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao6(x);
                        }
                        printf("%lf", sum);
                        resultado = (((funcao6(a) + (2*sum) + funcao6(b))) * h) / 2;
                        Limpeza();
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 7 :
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Valor de x: ");
                        scanf("%lf", &x);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        h = (b-a)/N;
                        printf("valor de h: %lf\n\n", h);
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao7(x);
                        }
                        printf("%lf", sum);
                        resultado = (((funcao7(a) + (2*sum) + funcao7(b))) * h) / 2;
                        Limpeza();
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 8 :
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Valor de x: ");
                        scanf("%lf", &x);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        a = (a* 3.14159265359)/ 180;
                        b = (b* 3.14159265359)/ 180;
                        h = (b-a)/N;
                        printf("valor de h: %lf\n\n", h);
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao8(x);
                        }
                        printf("%lf", sum);
                        resultado = (((funcao8(a) + (2*sum) + funcao8(b))) * h) / 2;
                        Limpeza();
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 9 :
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Valor de x: ");
                        scanf("%lf", &x);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        a = (a* 3.14159265359)/ 180;
                        b = (b* 3.14159265359)/ 180;
                        h = (b-a)/N;
                        printf("valor de h: %lf\n\n", h);
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao9(x);
                        }
                        printf("%lf", sum);
                        resultado = (((funcao9(a) + (2*sum) + funcao9(b))) * h) / 2;
                        Limpeza();
                        printf("\nResultado: %lf\n", resultado);
                        break;
                    case 10 :
                        printf("Valor de a: ");
                        scanf("%lf", &a);
                        printf("Valor de b: ");
                        scanf("%lf", &b);
                        printf("Valor de x: ");
                        scanf("%lf", &x);
                        printf("Numero de particoes: ");
                        scanf("%lf", &N);
                        a = (a* 3.14159265359)/ 180;
                        b = (b* 3.14159265359)/ 180;
                        h = (b-a)/N;
                        printf("valor de h: %lf\n\n", h);
                        for (i=1;i<=N-1;i++){
                        x = a + (i*h);
                        sum = sum + funcao10(x);
                        }
                        printf("%lf", sum);
                        resultado = (((funcao10(a) + (2*sum) + funcao10(b))) * h) / 2;
                        Limpeza();
                        printf("\nResultado: %lf\n", resultado);
                        break;

                }
                break;
        }
    }while(m1 !=4 || m2 != 4 || m3!= 4 || m4!= 4);

}
