#include <math.h>
static double funcao6(double x)
{
    return (log(x));
}
